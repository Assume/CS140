package pippin;

public class IllegalInstructionException extends RuntimeException {

	public IllegalInstructionException() {

	}

	public IllegalInstructionException(String message) {
		super(message);

	}

}
