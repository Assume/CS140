package pippin;

public class ParityCheckException extends RuntimeException {

	public ParityCheckException() {

	}

	public ParityCheckException(String message) {
		super(message);
	}

}
