package pippin;

public class CodeAccessException extends RuntimeException {

	public CodeAccessException() {

	}

	public CodeAccessException(String message) {
		super(message);
	}

}
